# GameFighters
Jogo 2D sendo desenvolvido na Unity.

**Não se tem objetivo claro de como será o game.**

## Cenas do protótipo:

### Hero Idle:

![](imagens/ft1.png)


### Hero Jump:

![](imagens/ft2.png)

### Hero Run:

![](imagens/ft3.png)
